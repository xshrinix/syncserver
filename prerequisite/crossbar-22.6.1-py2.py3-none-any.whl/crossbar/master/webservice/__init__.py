##############################################################################
#
#                        Crossbar.io
#     Copyright (C) Crossbar.io Technologies GmbH. All rights reserved.
#
##############################################################################

from .registerme import RouterWebServiceRegisterMe

__all__ = ('RouterWebServiceRegisterMe', )
