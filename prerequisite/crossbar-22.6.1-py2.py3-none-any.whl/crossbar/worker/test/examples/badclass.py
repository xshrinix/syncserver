#####################################################################################
#
#  Copyright (c) Crossbar.io Technologies GmbH
#  SPDX-License-Identifier: EUPL-1.2
#
#####################################################################################


class AppSession(object):
    def __init__(self, ignored):
        """
        A AppSession that doesn't descend from ApplicationSession.
        """
