###############################################################################
#
# Crossbar.io Master
# Copyright (c) Crossbar.io Technologies GmbH. Licensed under EUPLv1.2.
#
###############################################################################
# Don't ask me why this is needed, Sublime / py.test is an interesting
# combination ...
