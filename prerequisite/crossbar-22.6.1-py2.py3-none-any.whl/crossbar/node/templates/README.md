Template for initialization of a new Crossbar.io node with a simple (insecure) development configuration.
