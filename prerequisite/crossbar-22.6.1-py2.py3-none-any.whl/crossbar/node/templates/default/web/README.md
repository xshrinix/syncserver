Put your Web files here. Eg a "index.html" file would automatically render (and hide this otherwise generated directory listing.)

Other URLs and Web services configured in this example node configuration:

* `/ws`: WAMP-over-WebSocket endpoint with default "realm1" (anonymous authentication and everything allowed!)
* `/info`: Node info page
